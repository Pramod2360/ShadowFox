# Hangman Game (Python)

A classic word guessing game implemented in Python with multiple interfaces:

- **CLI** (Command Line)
- **GUI** (Tkinter)
- **Web App** (Flask)

## Setup
```bash
git clone https://github.com/YOUR_USERNAME/hangman-game.git
cd hangman-game

python -m venv venv
source venv/bin/activate   # Linux/Mac
venv\Scripts\activate      # Windows

pip install -r requirements.txt
```

## Run
### CLI
```bash
python hangman_cli.py
```

### Tkinter GUI
```bash
python hangman_tkinter.py
```

### Flask Web App
```bash
cd flask_app
python app.py
```
Visit http://127.0.0.1:5000/

## Tests
```bash
python -m unittest discover -s tests
```

## Requirements
See `requirements.txt`

## License
MIT License
