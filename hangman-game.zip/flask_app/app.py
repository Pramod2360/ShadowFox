from flask import Flask, render_template, request, session
import random

app = Flask(__name__)
app.secret_key = "hangman_secret"

WORDS = ["python", "hangman", "developer", "openai", "github"]

@app.route("/", methods=["GET", "POST"])
def index():
    if "word" not in session:
        session["word"] = random.choice(WORDS)
        session["guessed"] = ["_"] * len(session["word"])
        session["attempts"] = 6

    message = ""
    if request.method == "POST":
        char = request.form["guess"].lower()
        if char in session["word"]:
            for i, c in enumerate(session["word"]):
                if c == char:
                    session["guessed"][i] = c
        else:
            session["attempts"] -= 1

        if "_" not in session["guessed"]:
            message = "You won!"
        elif session["attempts"] == 0:
            message = f"Game over! Word was {session['word']}"

    return render_template("index.html",
                           guessed=" ".join(session["guessed"]),
                           attempts=session["attempts"],
                           message=message)

if __name__ == "__main__":
    app.run(debug=True)
