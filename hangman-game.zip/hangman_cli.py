import random

WORDS = ["python", "hangman", "developer", "openai", "github"]

def play():
    word = random.choice(WORDS)
    guessed = ["_"] * len(word)
    attempts = 6
    guessed_letters = set()

    print("Welcome to Hangman!")
    while attempts > 0 and "_" in guessed:
        print("Word:", " ".join(guessed))
        print("Attempts left:", attempts)
        guess = input("Enter a letter: ").lower()
        if guess in guessed_letters:
            print("Already guessed!")
            continue
        guessed_letters.add(guess)

        if guess in word:
            for i, c in enumerate(word):
                if c == guess:
                    guessed[i] = c
        else:
            attempts -= 1

    if "_" not in guessed:
        print("You won! Word was:", word)
    else:
        print("Game over! Word was:", word)

if __name__ == "__main__":
    play()
