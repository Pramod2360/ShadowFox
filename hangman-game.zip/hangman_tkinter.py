import tkinter as tk
import random

WORDS = ["python", "hangman", "developer", "openai", "github"]

class HangmanGame:
    def __init__(self, master):
        self.word = random.choice(WORDS)
        self.guessed = ["_"] * len(self.word)
        self.attempts = 6

        self.label = tk.Label(master, text=" ".join(self.guessed), font=("Arial", 18))
        self.label.pack()

        self.entry = tk.Entry(master)
        self.entry.pack()

        self.button = tk.Button(master, text="Guess", command=self.guess)
        self.button.pack()

        self.status = tk.Label(master, text=f"Attempts left: {self.attempts}")
        self.status.pack()

    def guess(self):
        char = self.entry.get().lower()
        self.entry.delete(0, tk.END)

        if char in self.word:
            for i, c in enumerate(self.word):
                if c == char:
                    self.guessed[i] = c
        else:
            self.attempts -= 1

        self.label.config(text=" ".join(self.guessed))
        self.status.config(text=f"Attempts left: {self.attempts}")

        if "_" not in self.guessed:
            self.status.config(text="You won!")
            self.button.config(state=tk.DISABLED)
        elif self.attempts == 0:
            self.status.config(text=f"Game over! Word was {self.word}")
            self.button.config(state=tk.DISABLED)

if __name__ == "__main__":
    root = tk.Tk()
    root.title("Hangman Game")
    HangmanGame(root)
    root.mainloop()
