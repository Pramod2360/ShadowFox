import unittest
from hangman_cli import WORDS

class TestHangman(unittest.TestCase):
    def test_word_list(self):
        self.assertTrue(len(WORDS) > 0)
        self.assertTrue(all(isinstance(w, str) for w in WORDS))

if __name__ == "__main__":
    unittest.main()
