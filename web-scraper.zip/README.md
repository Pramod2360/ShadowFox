# Web Scraper (Python)

This project demonstrates how to scrape quotes and authors from [quotes.toscrape.com](https://quotes.toscrape.com) using Python.

## Features
- Fetch multiple pages with `requests`
- Parse HTML with `BeautifulSoup`
- Save data to CSV with `pandas`
- Basic robots.txt check
- Retry handling and polite delays

## Setup
```bash
git clone https://github.com/YOUR_USERNAME/web-scraper.git
cd web-scraper

python -m venv venv
source venv/bin/activate   # Linux/Mac
venv\Scripts\activate      # Windows

pip install -r requirements.txt
```

## Run
```bash
python scrape_quotes_bs4.py
```

The output is saved in `data/quotes.csv`.

## Requirements
See `requirements.txt`

## License
MIT License
