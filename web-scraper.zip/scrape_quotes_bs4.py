import requests
from bs4 import BeautifulSoup
import pandas as pd
import time

BASE_URL = "https://quotes.toscrape.com/page/{}/"
quotes = []

for page in range(1, 6):  # scrape first 5 pages
    url = BASE_URL.format(page)
    response = requests.get(url)
    if response.status_code != 200:
        break
    soup = BeautifulSoup(response.text, "lxml")
    for q in soup.select(".quote"):
        text = q.select_one(".text").get_text(strip=True)
        author = q.select_one(".author").get_text(strip=True)
        quotes.append({"text": text, "author": author})
    time.sleep(1)

df = pd.DataFrame(quotes)
df.to_csv("quotes.csv", index=False)
print("Scraping complete. Saved to quotes.csv")
